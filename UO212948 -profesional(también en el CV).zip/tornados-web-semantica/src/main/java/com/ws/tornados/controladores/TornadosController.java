package com.ws.tornados.controladores;

import java.util.ArrayList;
import java.util.List;

import org.apache.jena.graph.BlankNodeId;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSet;
import org.apache.jena.rdf.model.Literal;
import org.apache.jena.rdf.model.RDFNode;
import org.apache.jena.rdf.model.Resource;
import org.apache.jena.rdfconnection.RDFConnection;
import org.apache.jena.rdfconnection.RDFConnectionFuseki;
import org.apache.jena.rdfconnection.RDFConnectionFuseki.RDFConnectionFusekiBuilder;
import org.apache.jena.rdflink.RDFConnectionAdapter;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ws.model.Resultado;
import com.ws.model.Tripleta;

@Controller
public class TornadosController {
	
	private RDFConnectionFusekiBuilder builderCon = (RDFConnectionFusekiBuilder) RDFConnectionFuseki.create()
			.destination("http://156.35.98.103:3030/tornados/sparql");
	
	@GetMapping("/")
	public String inicio(Model model) {
		String busquedaBasica = "SELECT distinct ?s ?p ?o\n" +
				"WHERE {\n" +
		        "?s ?p ?o \n" +
		 "}";
		
		final String beginLocation = "2NE METAMORA";
		final String initDate = "2004-07-13T13:52:00";
		
		String busquedaPorLocalizacion =
				"SELECT ?s ?o ?p\n" +
			      " WHERE {\n" +
			          "?s ?o ?p\n" +
			        "FILTER (?p = '" + beginLocation +"'^^<http://schema.org/beginLocation>)\n" +
			      "}\n";
		
		String busquedaPorFecha =
				"SELECT ?s ?o ?p\n" +
			      " WHERE {\n" +
			          "?s ?o ?p\n" +
			        "FILTER (?p <= '" + initDate +"'^^<http://www.w3.org/2001/XMLSchema#Datetime>)\n" +
			        "FILTER (?o = <http://example.org/initDateTime>)\n" +
			      "}\n";
		
		List<Tripleta> tripletasConsultaLocation = new ArrayList<Tripleta>();
		List<Tripleta> tripletasConsultaBasica = new ArrayList<Tripleta>();
		List<Tripleta> tripletasConsultaFecha = new ArrayList<Tripleta>();
		
		List<Tripleta> tripletasResultado1 = new ArrayList<Tripleta>();
		List<Tripleta> tripletasResultado2 = new ArrayList<Tripleta>();

		model.addAttribute("consulta1", busquedaPorLocalizacion);

		try (RDFConnection con = builderCon.build()) {

			QueryExecution query = con.query(busquedaPorLocalizacion);
			ResultSet rs = query.execSelect();
			while (rs.hasNext()) {
				QuerySolution sol = rs.next();
				try {
					Tripleta tl = new Tripleta(sol.getResource("s"), sol.getResource("o"), sol.getLiteral("p"));
					tripletasConsultaLocation.add(tl);

				} catch (Exception e) {
				}
			}
		}
		try (RDFConnection con = builderCon.build()) {

			QueryExecution query = con.query(busquedaPorFecha);
			ResultSet rs = query.execSelect();
			while (rs.hasNext()) {
				QuerySolution sol = rs.next();
				try {
					Tripleta tf = new Tripleta(sol.getResource("s"), sol.getResource("o"), sol.getLiteral("p"));
					tripletasConsultaFecha.add(tf);

				} catch (Exception e) {
				}
			}
		}
		try (RDFConnection con = builderCon.build()) {

			QueryExecution query = con.query(busquedaBasica);
			ResultSet rs = query.execSelect();
			while (rs.hasNext()) {
				QuerySolution sol = rs.next();
				try {
					Tripleta tb = new Tripleta(sol.getResource("s"), sol.getResource("p"), sol.getLiteral("o"));
					tripletasConsultaBasica.add(tb);

				} catch (Exception e) {
				}
			}
		}
		String resultado1 = "";
		String resultado2 = "";
		for (Tripleta t1 : tripletasConsultaLocation)
			for (Tripleta t2 : tripletasConsultaBasica)
				if (t1.getS().toString().equals(t2.getS().toString()))
					tripletasResultado1.add(t2);
		
		for (Tripleta t1 : tripletasConsultaFecha)
			for (Tripleta t2 : tripletasConsultaBasica)
				if (t1.getS().toString().equals(t2.getS().toString()))
					tripletasResultado2.add(t2);
		
		for (Tripleta elem : tripletasResultado1) {
			resultado1 += "<b>s</b>: " + elem.getS().toString();
			resultado1 += ", <b>p</b>: " + elem.getP().toString();
			resultado1 += ", <b>o</b>: " + elem.getO().toString() + "</br>";
		}
		
		for (Tripleta elem : tripletasResultado2) {
			resultado2 += "<b>s</b>: " + elem.getS().toString();
			resultado2 += ", <b>p</b>: " + elem.getP().toString();
			resultado2 += ", <b>o</b>: " + elem.getO().toString() + "</br>";
		}
		;

		model.addAttribute("resultado1", resultado1);
		model.addAttribute("resultado2", resultado2);

		return "inicio";
	}
	

}
