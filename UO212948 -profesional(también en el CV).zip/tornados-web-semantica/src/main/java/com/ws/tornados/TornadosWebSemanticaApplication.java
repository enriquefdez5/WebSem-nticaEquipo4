package com.ws.tornados;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TornadosWebSemanticaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TornadosWebSemanticaApplication.class, args);
	}

}
