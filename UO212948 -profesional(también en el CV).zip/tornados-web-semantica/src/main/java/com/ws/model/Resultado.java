package com.ws.model;

import org.apache.jena.rdf.model.Literal;
import org.apache.jena.rdf.model.Resource;

public class Resultado {
	private Resource s;
	private Resource p;
	private Literal o;
	private Resource s2;
	private Resource p2;
	private Literal o2;
	
	public Resultado(Resource s, Resource p, Literal o, Resource s2, Resource p2, Literal o2) {
		super();
		this.s = s;
		this.p = p;
		this.o = o;
		this.s2 = s2;
		this.p2 = p2;
		this.o2 = o2;
	}

	public Resource getS() {
		return s;
	}

	public void setS(Resource s) {
		this.s = s;
	}

	public Resource getP() {
		return p;
	}

	public void setP(Resource p) {
		this.p = p;
	}

	public Literal getO() {
		return o;
	}

	public void setO(Literal o) {
		this.o = o;
	}

	public Resource getS2() {
		return s2;
	}

	public void setS2(Resource s2) {
		this.s2 = s2;
	}

	public Resource getP2() {
		return p2;
	}

	public void setP2(Resource p2) {
		this.p2 = p2;
	}

	public Literal getO2() {
		return o2;
	}

	public void setO2(Literal o2) {
		this.o2 = o2;
	}
	
}


