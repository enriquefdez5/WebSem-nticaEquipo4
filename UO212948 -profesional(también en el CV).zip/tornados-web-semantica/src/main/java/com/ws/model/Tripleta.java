package com.ws.model;

import org.apache.jena.rdf.model.Literal;
import org.apache.jena.rdf.model.Resource;

public class Tripleta {
	private Resource s;
	private Resource p;
	private Literal o;
	
	public Tripleta(Resource s, Resource p, Literal o) {
		super();
		this.s = s;
		this.p = p;
		this.o = o;
	}
	public Resource getS() {
		return s;
	}
	public void setS(Resource s) {
		this.s = s;
	}
	public Resource getP() {
		return p;
	}
	public void setP(Resource p) {
		this.p = p;
	}
	public Literal getO() {
		return o;
	}
	public void setO(Literal o) {
		this.o = o;
	}
	
	
}


