package com.ws.tornados;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TornadosWebSemanticaApplicationTests {

	@Test
	void contextLoads() {
	}

}
